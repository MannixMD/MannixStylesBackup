(function () {
	var d = new Date();
	document.getElementById("cosmos-sunspots").src = "https://sohowww.nascom.nasa.gov/data/synoptic/sunspots_earth/mdi_sunspots.jpg?ver=" + d.getHours() + d.getDate() + d.getMonth() + d.getFullYear();
})();
