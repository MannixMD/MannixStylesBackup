;(function($) {
	$(document).ready(function() {
		//var $button = $('.icon-logout a'),
		var $button	= $('a[href*="ucp.php?mode=login"]')
		$button.attr("data-bs-toggle","modal")
		$button.attr("data-bs-target","#quickLogin")
		$button.click(function(e){
			e.preventDefault();
		});

	});
})(jQuery);
