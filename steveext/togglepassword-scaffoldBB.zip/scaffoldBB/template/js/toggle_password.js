/* global phpbb */

(($) => {  // Avoid conflicts with other libraries

	'use strict';

	var icon = $('a.toggle-password i.icon'),
		eye = "fa-eye fa-eye-slash icon-red";

	$.extend(phpbb, {
		togglePassword: (iD) => {
			if (iD.prop("type") === "password") {
				iD.prop("type", "text").addClass('toggle-password');
			} else {
				iD.prop("type", "password").removeClass('toggle-password');
			}
			return this;
		},
		href: (iD, data) => {
			var url = $("<a />", {
				href: "#",
				class: data,
				text: ""
			})
				.attr(data, "true")
				.html(" <i class='icon fa fa-eye icon-red fa-fw' aria-hidden='true'></i> ");

			return $(iD).after(url);
		},
		data: {
			input: [
				{
					name: '#' + admin.index,
					button: 'data-toggle-admin-password'
				},
				{
					name: '#password_confirm',
					button: 'data-toggle-password-confirm'
				},
				{
					name: '#forum_password',
					button: 'data-toggle-forum-password'
				},
				{
					name: '#forum_password_confirm',
					button: 'data-toggle-forum-password-confirm'
				},
				{
					name: '#new_password',
					button: 'data-toggle-new-password'
				},
				{
					name: '#cur_password',
					button: 'data-toggle-cur-password'
				},
				{
					name: '#ql-password',
					button: 'data-toggle-password'
				},
				{
					name: '#smtp_password',
					button: 'data-toggle-smpt-password'
				},
			]
		}
	});

	$(window).on('load', () => {

		$.each(phpbb.data.input, (key, val) => {
			phpbb.href($(val.name), val.button);
			if ($('[' + val.button + ']').length > 0) {
				$('[' + val.button + ']').parent().addClass('d-flex align-items-center')
			}
			//clicky function
			$(document).on('click', '[' + val.button + '=true]', (e) => {
				e.preventDefault();
				$('a' + val.button + ' i.icon').toggleClass(eye);
				phpbb.togglePassword($(val.name));
			});
		});
	});

})(jQuery); // Avoid conflicts with other libraries