phpbb.addAjaxCallback('participate', function(res) {
	'use strict';
	if (res.success) {
		var $button = $('#participate_button');
		var $bar = $('#participate_bar');
		var $btn_class = res.DMZX_PARTICIPATE_STATUS_CLASS == 'btn-red' ? 'btn-danger' : 'btn-success'
		$button
			.html(res.DMZX_PARTICIPATE_TXT)
			.attr('class', res.DMZX_PARTICIPATE_STATUS_CLASS + ' ' + $btn_class + " button icon-button btn btn-sm")
			.attr('title', res.DMZX_PARTICIPATE_BUTTON_TXT);
		$bar.html(res.PARTICIPANTSBAR);
	}
});