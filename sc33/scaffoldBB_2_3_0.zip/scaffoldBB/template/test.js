// function to hide postbuttons if the buttons wrap to next line
function respBtns() {
	let postbody = document.querySelectorAll(".postbody");
	postbody.forEach((post) => {
		let ul = post.querySelector("ul");
		let li = [...ul.querySelectorAll("li")];
		const liWidth = li.reduce(computeTotalWidth, 0);
		if (liWidth > ul.clientWidth) {
			li.forEach((el) => {
				el.classList.toggle("d-none");
			});
		}
	});
}
respBtns();
window.addEventListener("resize", respBtns);

// OLD RESPONSIVE NAVIGATION
// let navItems = [
// 	...document.querySelectorAll(".responsive-menu [data-last-responsive]"),
// ]; // all items to hide in the top nav
// let quickLinksMenu = document.querySelector("#QuickLinks"); // quick links container
// let navigation = document.querySelector("#main-nav"); // top navigation container
// let navFirstChildHeight = 0;

// let footerItems = [
// 	...document.querySelectorAll("#footerLinks [data-last-responsive]"),
// ]; // all items to hide in the footer nav
// let footerLinks = document.querySelector("#footerLinks"); // bottom nav links container
// let footerBreadcrumbs = document.querySelector("#footerBreadcrumbs"); // bottom nav breadcrumbs container
// let footerMenuList = document.querySelector("#responsive-menu-footer"); // bottom nav item list
// const footerMenuButton = document.querySelector(".responsive-menu-footer"); // bottom nav menu dropdown

// function computeTotalWidth(totalWidth, currentItem) {
// 	"use strict";
// 	return totalWidth + currentItem.clientWidth;
// }

// const topNavResponsiveItemsTotalWidth = navItems.reduce(computeTotalWidth, 0);
// const bottomNavResponsiveItemsTotalWidth = footerItems.reduce(
// 	computeTotalWidth,
// 	0
// );

// function cloneHeaderNav() {
// 	"use strict";
// 	for (let navItem of navItems) {
// 		navItem.classList.add("hidden");
// 		let cloneItem = navItem.cloneNode(true);
// 		quickLinksMenu.appendChild(cloneItem);
// 	}
// 	const QuickLinksItems = [
// 		...document.querySelectorAll("#QuickLinks [data-last-responsive]"),
// 	];
// 	for (const QuickLinksItem of QuickLinksItems) {
// 		QuickLinksItem.classList.remove("nav-item", "hidden");
// 	}
// 	const QuickLinksLinks = document.querySelectorAll(
// 		"#QuickLinks [data-last-responsive] a"
// 	);
// 	for (const QuickLinksLink of QuickLinksLinks) {
// 		QuickLinksLink.classList.remove(
// 			"nav-link",
// 			"px-1",
// 			"py-0",
// 			"text-body"
// 		);
// 		QuickLinksLink.classList.add("dropdown-item");
// 	}
// }
// function showHeaderNav() {
// 	"use strict";
// 	for (let navItem of navItems) {
// 		navItem.classList.remove("hidden");
// 	}
// 	const QuickLinksItems = document.querySelectorAll(
// 		"#QuickLinks [data-last-responsive]"
// 	);
// 	for (const QuickLinksItem of QuickLinksItems) {
// 		QuickLinksItem.remove();
// 	}
// }

// function cloneFooterNav() {
// 	"use strict";
// 	footerMenuButton.classList.remove("hidden");
// 	for (let footerItem of footerItems) {
// 		footerItem.classList.add("hidden");
// 		const clonedItem = footerItem.cloneNode(true);
// 		footerMenuList.appendChild(clonedItem);
// 	}
// 	let dropdownFooterItems = [
// 		...document.querySelectorAll(
// 			"#responsive-menu-footer [data-last-responsive]"
// 		),
// 	];
// 	for (let dropdownFooterItem of dropdownFooterItems) {
// 		dropdownFooterItem.classList.remove("hidden", "nav-item");
// 	}
// 	let dropdownFooterLinks = [
// 		...document.querySelectorAll("#responsive-menu-footer > * > *"),
// 	];
// 	for (let dropdownFooterLink of dropdownFooterLinks) {
// 		dropdownFooterLink.classList.remove(
// 			"nav-link",
// 			"py-0",
// 			"px-1",
// 			"text-body"
// 		);
// 		dropdownFooterLink.classList.add("dropdown-item");
// 	}
// }
// function showFooterNav() {
// 	"use strict";
// 	footerMenuButton.classList.add("hidden");
// 	for (let footerItem of footerItems) {
// 		footerItem.classList.remove("hidden");
// 	}
// 	let dropdownFooterItems = [
// 		...document.querySelectorAll(
// 			"#responsive-menu-footer [data-last-responsive]"
// 		),
// 	];
// 	for (let dropdownFooterItem of dropdownFooterItems) {
// 		dropdownFooterItem.remove();
// 	}
// }
// function NavSize() {
// 	"use strict";
// 	if (navigation !== null || footerLinks !== null) {
// 		let NavBarTop = document.querySelector(".responsive-menu");
// 		let UserBar = document.querySelector("#user-nav");
// 		let emptySpaceTop =
// 			NavBarTop.clientWidth -
// 			(navigation.clientWidth + UserBar.clientWidth);
// 		let NavBarBottom = document.querySelector("#NavBarFooter");
// 		let emptySpaceBottom =
// 			NavBarBottom.clientWidth -
// 			(footerLinks.clientWidth + footerBreadcrumbs.clientWidth);
// 		let navFirstChildHeight = navigation.firstElementChild.clientHeight;
// 		if (
// 			navigation.clientWidth + emptySpaceTop >
// 			topNavResponsiveItemsTotalWidth
// 		) {
// 			showHeaderNav();
// 		}

// 		if (navigation.clientHeight > navFirstChildHeight) {
// 			cloneHeaderNav();
// 		}

// 		if (
// 			footerLinks.clientWidth + emptySpaceBottom >
// 			bottomNavResponsiveItemsTotalWidth
// 		) {
// 			showFooterNav();
// 		}

// 		if (footerLinks.clientHeight > navFirstChildHeight) {
// 			cloneFooterNav();
// 		}
// 	}
// }

// NavSize();
// window.addEventListener("resize", NavSize);
