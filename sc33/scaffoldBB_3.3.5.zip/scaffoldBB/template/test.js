// script to move all links from dropdowns to main navigation when navigation is not expanded
const nav = document.querySelector("#HeaderNavigation");
const ql = document.querySelector(".quick-links .dropdown-toggle");
const dropdown = document.querySelector(".quick-links > div");
const links = [...document.querySelectorAll("#QuickLinksDropdownMenu > li")];
const profileMenuDropdown = document.querySelector("#username_logged_in > div");
const profileMenuLinks = [
	...document.querySelectorAll("#username_logged_in > div li"),
];
const profileLink = document.querySelector("#username_logged_in > a");
const concat = links.concat(profileMenuLinks);
const filtered = concat.filter((link) =>
	link.firstElementChild.classList.contains("dropdown-item")
);
const hrs = concat.filter((link) =>
	link.firstElementChild.classList.contains("dropdown-divider")
);
function check() {
	if (!nav.classList.contains("navbar-expand")) {
		ql.classList.add("hidden");
		profileLink.classList.add("hidden");
		dropdown.classList.add("show");
		dropdown.classList.remove("dropdown-menu");
		profileMenuDropdown.classList.add("show");
		profileMenuDropdown.classList.remove("dropdown-menu");
		filtered.forEach((link) => link.classList.add("nav-item"));
		filtered.forEach((link) =>
			link.firstElementChild.classList.replace(
				"dropdown-item",
				"nav-link"
			)
		);
		filtered.forEach((link) =>
			link.firstElementChild.classList.add("px-1", "py-0", "text-body")
		);
		hrs.forEach((hr) => hr.classList.add("hidden"));
		const dropdownLinks = document.querySelectorAll(
			"#MainNavigation .nav-item"
		);
		dropdownLinks.forEach((link) =>
			link.firstElementChild.classList.replace("py-0", "py-1")
		);
	} else {
		ql.classList.remove("hidden");
		profileLink.classList.remove("hidden");
		dropdown.classList.remove("show");
		dropdown.classList.add("dropdown-menu");
		profileMenuDropdown.classList.remove("show");
		profileMenuDropdown.classList.add("dropdown-menu");
		filtered.forEach((link) => link.classList.remove("nav-item"));
		filtered.forEach((link) =>
			link.firstElementChild.classList.replace(
				"nav-link",
				"dropdown-item"
			)
		);
		filtered.forEach((link) =>
			link.firstElementChild.classList.remove("px-1", "py-0", "text-body")
		);
		hrs.forEach((hr) => hr.classList.remove("hidden"));
		const dropdownLinks = document.querySelectorAll(
			"#MainNavigation .nav-item"
		);
		dropdownLinks.forEach((link) =>
			link.firstElementChild.classList.replace("py-1", "py-0")
		);
	}
}
check();
window.addEventListener("resize", check);

// function to hide postbuttons if the buttons wrap to next line
function respBtns() {
	let postbody = document.querySelectorAll(".postbody");
	postbody.forEach((post) => {
		let ul = post.querySelector("ul");
		let li = [...ul.querySelectorAll("li")];
		const liWidth = li.reduce(computeTotalWidth, 0);
		if (liWidth > ul.clientWidth) {
			li.forEach((el) => {
				el.classList.toggle("d-none");
			});
		}
	});
}
respBtns();
window.addEventListener("resize", respBtns);

// OLD RESPONSIVE NAVIGATION
// let navItems = [
// 	...document.querySelectorAll(".responsive-menu [data-last-responsive]"),
// ]; // all items to hide in the top nav
// let quickLinksMenu = document.querySelector("#QuickLinks"); // quick links container
// let navigation = document.querySelector("#main-nav"); // top navigation container
// let navFirstChildHeight = 0;

// let footerItems = [
// 	...document.querySelectorAll("#footerLinks [data-last-responsive]"),
// ]; // all items to hide in the footer nav
// let footerLinks = document.querySelector("#footerLinks"); // bottom nav links container
// let footerBreadcrumbs = document.querySelector("#footerBreadcrumbs"); // bottom nav breadcrumbs container
// let footerMenuList = document.querySelector("#responsive-menu-footer"); // bottom nav item list
// const footerMenuButton = document.querySelector(".responsive-menu-footer"); // bottom nav menu dropdown

// function computeTotalWidth(totalWidth, currentItem) {
// 	"use strict";
// 	return totalWidth + currentItem.clientWidth;
// }

// const topNavResponsiveItemsTotalWidth = navItems.reduce(computeTotalWidth, 0);
// const bottomNavResponsiveItemsTotalWidth = footerItems.reduce(
// 	computeTotalWidth,
// 	0
// );

// function cloneHeaderNav() {
// 	"use strict";
// 	for (let navItem of navItems) {
// 		navItem.classList.add("hidden");
// 		let cloneItem = navItem.cloneNode(true);
// 		quickLinksMenu.appendChild(cloneItem);
// 	}
// 	const QuickLinksItems = [
// 		...document.querySelectorAll("#QuickLinks [data-last-responsive]"),
// 	];
// 	for (const QuickLinksItem of QuickLinksItems) {
// 		QuickLinksItem.classList.remove("nav-item", "hidden");
// 	}
// 	const QuickLinksLinks = document.querySelectorAll(
// 		"#QuickLinks [data-last-responsive] a"
// 	);
// 	for (const QuickLinksLink of QuickLinksLinks) {
// 		QuickLinksLink.classList.remove(
// 			"nav-link",
// 			"px-1",
// 			"py-0",
// 			"text-body"
// 		);
// 		QuickLinksLink.classList.add("dropdown-item");
// 	}
// }
// function showHeaderNav() {
// 	"use strict";
// 	for (let navItem of navItems) {
// 		navItem.classList.remove("hidden");
// 	}
// 	const QuickLinksItems = document.querySelectorAll(
// 		"#QuickLinks [data-last-responsive]"
// 	);
// 	for (const QuickLinksItem of QuickLinksItems) {
// 		QuickLinksItem.remove();
// 	}
// }

// function cloneFooterNav() {
// 	"use strict";
// 	footerMenuButton.classList.remove("hidden");
// 	for (let footerItem of footerItems) {
// 		footerItem.classList.add("hidden");
// 		const clonedItem = footerItem.cloneNode(true);
// 		footerMenuList.appendChild(clonedItem);
// 	}
// 	let dropdownFooterItems = [
// 		...document.querySelectorAll(
// 			"#responsive-menu-footer [data-last-responsive]"
// 		),
// 	];
// 	for (let dropdownFooterItem of dropdownFooterItems) {
// 		dropdownFooterItem.classList.remove("hidden", "nav-item");
// 	}
// 	let dropdownFooterLinks = [
// 		...document.querySelectorAll("#responsive-menu-footer > * > *"),
// 	];
// 	for (let dropdownFooterLink of dropdownFooterLinks) {
// 		dropdownFooterLink.classList.remove(
// 			"nav-link",
// 			"py-0",
// 			"px-1",
// 			"text-body"
// 		);
// 		dropdownFooterLink.classList.add("dropdown-item");
// 	}
// }
// function showFooterNav() {
// 	"use strict";
// 	footerMenuButton.classList.add("hidden");
// 	for (let footerItem of footerItems) {
// 		footerItem.classList.remove("hidden");
// 	}
// 	let dropdownFooterItems = [
// 		...document.querySelectorAll(
// 			"#responsive-menu-footer [data-last-responsive]"
// 		),
// 	];
// 	for (let dropdownFooterItem of dropdownFooterItems) {
// 		dropdownFooterItem.remove();
// 	}
// }
// function NavSize() {
// 	"use strict";
// 	if (navigation !== null || footerLinks !== null) {
// 		let NavBarTop = document.querySelector(".responsive-menu");
// 		let UserBar = document.querySelector("#user-nav");
// 		let emptySpaceTop =
// 			NavBarTop.clientWidth -
// 			(navigation.clientWidth + UserBar.clientWidth);
// 		let NavBarBottom = document.querySelector("#NavBarFooter");
// 		let emptySpaceBottom =
// 			NavBarBottom.clientWidth -
// 			(footerLinks.clientWidth + footerBreadcrumbs.clientWidth);
// 		let navFirstChildHeight = navigation.firstElementChild.clientHeight;
// 		if (
// 			navigation.clientWidth + emptySpaceTop >
// 			topNavResponsiveItemsTotalWidth
// 		) {
// 			showHeaderNav();
// 		}

// 		if (navigation.clientHeight > navFirstChildHeight) {
// 			cloneHeaderNav();
// 		}

// 		if (
// 			footerLinks.clientWidth + emptySpaceBottom >
// 			bottomNavResponsiveItemsTotalWidth
// 		) {
// 			showFooterNav();
// 		}

// 		if (footerLinks.clientHeight > navFirstChildHeight) {
// 			cloneFooterNav();
// 		}
// 	}
// }

// NavSize();
// window.addEventListener("resize", NavSize);



let navbars = document.querySelectorAll('nav .navbar-nav');

navbars.forEach(navbar =>{
    responsiveNavbars(navbar)
})
function responsiveNavbars(navbar) {
    const slack = 24;
    let items = [...navbar.querySelectorAll('.nav-item')];
    let navbarNavigationTotalWidth = items.reduce(computeTotalWidth,0);
    let spans = [...navbar.querySelectorAll(`[data-hidden]`)];
    let smWidth = spans.reduce(computeTotalWidth,0);
    let navbarNavigationTotalWidthShort = navbarNavigationTotalWidth - smWidth
    let isLongHidden = false;
    let isShortHidden = false;
    // calculate items widths when they are not hidden
    if(!isLongHidden && !isLongHidden){
        navbarNavigationTotalWidth = items.reduce(computeTotalWidth,0);
        smWidth = spans.reduce(computeTotalWidth,0);
        navbarNavigationTotalWidthShort = navbarNavigationTotalWidth - smWidth
    }

    if(!isLongHidden && navbar.clientWidth < navbarNavigationTotalWidth + slack){
        spans.forEach(span => span.classList.add('d-none'))
        isLongHidden = true
        console.log('1')
    }
    if(isLongHidden && navbar.clientWidth > navbarNavigationTotalWidth + slack){
        spans.forEach(span => span.classList.remove('d-none'))
        isLongHidden = false
        console.log('2')
    }
    if(isLongHidden && !isShortHidden && navbar.clientWidth < navbarNavigationTotalWidthShort + slack){
        HeaderNavigation.classList.remove("navbar-expand");
        spans.forEach(span => span.classList.remove('d-none'))
        isLongHidden = true;
        isShortHidden = true;
        console.log('3')
    }
    if(isLongHidden && isShortHidden && navbar.clientWidth > navbarNavigationTotalWidthShort + slack){
        spans.forEach(span => span.classList.add('d-none'))
        HeaderNavigation.classList.add("navbar-expand");
        isShortHidden = false;
        console.log('4')
    }
    if(!isLongHidden && !isShortHidden && navbar.clientWidth > navbarNavigationTotalWidthShort + slack){
        spans.forEach(span => span.classList.remove('d-none'))
        isShortHidden = false
        console.log('5')
    }
    if(isShortHidden && !isLongHidden && navbar.clientWidth > navbarNavigationTotalWidth + slack){
        HeaderNavigation.classList.add("navbar-expand");
        isLongHidden = false;
        console.log('6')      
    }
    if(isShortHidden && isLongHidden && navbar.clientWidth < navbarNavigationTotalWidth + slack){
        HeaderNavigation.classList.remove("navbar-expand");
        console.log('7')
    }
}


let HeaderNavigation = document.querySelector("#HeaderNavigation");
let HeaderNavigationAllItems = [
	...document.querySelectorAll("#MainNavigation > li"),
];
let FooterNavigation = document.querySelector("#FooterNavigation");
let FooterNavigationAllItems = [...FooterNavigation.querySelectorAll("li")];
let HeaderNavigationAllItemsTotalWidth = HeaderNavigationAllItems.reduce(computeTotalWidth,0);
let FooterNavigationAllItemsTotalWidth = FooterNavigationAllItems.reduce(computeTotalWidth,0);
const slack = 24;
let spans = [...document.querySelectorAll('[data-hidden]')]
let smWidth = spans.reduce(computeTotalWidth,0);
let HeaderNavigationAllItemsTotalWidthShort = HeaderNavigationAllItemsTotalWidth - smWidth
let isShortHidden = false;
let isLongHidden = false;
let isBottomHidden = false;

function responsiveNavbars() {
    if(!isLongHidden && !isShortHidden){
        HeaderNavigationAllItemsTotalWidth = HeaderNavigationAllItems.reduce(computeTotalWidth,0);
        smWidth = spans.reduce(computeTotalWidth,0);
        HeaderNavigationAllItemsTotalWidthShort = HeaderNavigationAllItemsTotalWidth - smWidth    
    }

    if(!isLongHidden && HeaderNavigation.clientWidth < HeaderNavigationAllItemsTotalWidth + slack){
        spans.forEach(span => span.classList.add('d-none'))
        isLongHidden = true
        console.log('1')
    }
    if(isLongHidden && !isShortHidden && HeaderNavigation.clientWidth > HeaderNavigationAllItemsTotalWidth + slack){
        spans.forEach(span => span.classList.remove('d-none'))
        isLongHidden = false
        console.log('2')
    }
    if(isLongHidden && !isShortHidden && (HeaderNavigation.clientWidth < HeaderNavigationAllItemsTotalWidthShort + slack || HeaderNavigation.clientWidth < HeaderNavigationAllItemsTotalWidth + slack)){
        HeaderNavigation.classList.remove("navbar-expand");
        spans.forEach(span => span.classList.remove('d-none'))
        isLongHidden = true;
        isShortHidden = true;
        console.log('3')
    }
    if(isLongHidden && isShortHidden && HeaderNavigation.clientWidth > HeaderNavigationAllItemsTotalWidthShort + slack){
        spans.forEach(span => span.classList.add('d-none'))
        HeaderNavigation.classList.add("navbar-expand");
        isShortHidden = false;
        console.log('4')
    }
    // if(!isLongHidden && !isShortHidden && HeaderNavigation.clientWidth > HeaderNavigationAllItemsTotalWidthShort + slack){
    //     spans.forEach(span => span.classList.remove('d-none'))
    //     isShortHidden = false
    //     console.log('5')
    // }
    if(isShortHidden && !isLongHidden && HeaderNavigation.clientWidth > HeaderNavigationAllItemsTotalWidth + slack){
        HeaderNavigation.classList.add("navbar-expand");
        isLongHidden = false;
        console.log('6')      
    }
    if(isShortHidden && isLongHidden && HeaderNavigation.clientWidth < HeaderNavigationAllItemsTotalWidth + slack){
        HeaderNavigation.classList.remove("navbar-expand");
        console.log('7')
    }

    if(!isBottomHidden){
        FooterNavigationAllItemsTotalWidth = FooterNavigationAllItems.reduce(computeTotalWidth,0);
    }
	if(!isBottomHidden && FooterNavigation.clientWidth < FooterNavigationAllItemsTotalWidth + slack){
        FooterNavigation.classList.remove('navbar-expand');
        isBottomHidden = true;
    }
    if(isBottomHidden && FooterNavigation.clientWidth > FooterNavigationAllItemsTotalWidth + slack){
        FooterNavigation.classList.add('navbar-expand');
        isBottomHidden = false;
    }
    
}

 responsiveNavbars();
 window.addEventListener("resize", responsiveNavbars);

 