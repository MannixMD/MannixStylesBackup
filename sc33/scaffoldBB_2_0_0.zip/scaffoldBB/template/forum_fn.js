/* global phpbb */

/**
* phpBB3 forum functions
*/

/**
* Find a member
*/
function find_username(url) {
	'use strict';

	popup(url, 760, 570, '_usersearch');
	return false;
}

/**
* Window popup
*/
function popup(url, width, height, name) {
	'use strict';

	if (!name) {
		name = '_popup';
	}

	window.open(url.replace(/&amp;/g, '&'), name, 'height=' + height + ',resizable=yes,scrollbars=yes, width=' + width);
	return false;
}

/**
* Jump to page
*/
function pageJump(item) {
	'use strict';

	var page = parseInt(item.val(), 10),
		perPage = item.attr('data-per-page'),
		baseUrl = item.attr('data-base-url'),
		startName = item.attr('data-start-name');

	if (page !== null && !isNaN(page) && page === Math.floor(page) && page > 0) {
		if (baseUrl.indexOf('?') === -1) {
			document.location.href = baseUrl + '?' + startName + '=' + ((page - 1) * perPage);
		} else {
			document.location.href = baseUrl.replace(/&amp;/g, '&') + '&' + startName + '=' + ((page - 1) * perPage);
		}
	}
}

/**
* Mark/unmark checklist
* id = ID of parent container, name = name prefix, state = state [true/false]
*/
function marklist(id, name, state) {
	'use strict';

	jQuery('#' + id + ' input[type=checkbox][name]').each(function () {
		var $this = jQuery(this);
		if ($this.attr('name').substr(0, name.length) === name && !$this.prop('disabled')) {
			$this.prop('checked', state);
		}
	});
}

/**
* Resize viewable area for attached image or topic review panel (possibly others to come)
* e = element
*/
function viewableArea(e, itself) {
	'use strict';

	if (!e) {
		return;
	}

	if (!itself) {
		e = e.parentNode;
	}

	if (!e.vaHeight) {
		// Store viewable area height before changing style to auto
		e.vaHeight = e.offsetHeight;
		e.vaMaxHeight = e.style.maxHeight;
		e.style.height = 'auto';
		e.style.maxHeight = 'none';
		e.style.overflow = 'visible';
	} else {
		// Restore viewable area height to the default
		e.style.height = e.vaHeight + 'px';
		e.style.overflow = 'auto';
		e.style.maxHeight = e.vaMaxHeight;
		e.vaHeight = false;
	}
}

/** 
 * Responsive Navigation
*/

let navItems = [...document.querySelectorAll('.responsive-menu [data-last-responsive]')];
let quickLinksMenu = document.querySelector('#QuickLinks');
let navigation = document.querySelector('#main-nav');
let navFirstChildHeight = navigation.firstElementChild.clientHeight;

function computeTotalWidth(totalWidth, currentNavItem) {
	'use strict';
	return totalWidth + currentNavItem.clientWidth;
}

const totalWidth = navItems.reduce(computeTotalWidth, 0);

function cloneHeaderNav() {
	'use strict';
	for (let navItem of navItems) {
		navItem.classList.add('hidden');
		let cloneItem = navItem.cloneNode(true);
		quickLinksMenu.appendChild(cloneItem);
	}
	const QuickLinksItems = [...document.querySelectorAll('#QuickLinks [data-last-responsive]')];
	for (const QuickLinksItem of QuickLinksItems) {
		QuickLinksItem.classList.remove('nav-item', 'hidden');
	}
	const QuickLinksLinks = document.querySelectorAll('#QuickLinks [data-last-responsive] a');
	for (const QuickLinksLink of QuickLinksLinks) {
		QuickLinksLink.classList.remove('nav-link', 'px-1', 'py-0', 'text-body')
		QuickLinksLink.classList.add('dropdown-item');
	}
}
function showHeaderNav() {
	'use strict';
	for (let navItem of navItems) {
		navItem.classList.remove('hidden');
	}		
	const QuickLinksItems = document.querySelectorAll('#QuickLinks [data-last-responsive]');
	for (const QuickLinksItem of QuickLinksItems) {
		QuickLinksItem.remove();
	}
}

let footerItems = [...document.querySelectorAll('#footerLinks [data-last-responsive]')];
let footerLinks = document.querySelector('#footerLinks');
let footerBreadcrumbs = document.querySelector('#footerBreadcrumbs');
let footerMenuList = document.querySelector('#responsive-menu-footer');
const footerMenuButton = document.querySelector('.responsive-menu-footer');

function computeTotalWidth(totalFooterWidth, currentFooterItem) {
	'use strict';
	return totalFooterWidth + currentFooterItem.clientWidth;
}

const totalFooterWidth = footerItems.reduce(computeTotalWidth, 0);

function cloneFooterNav() {
	'use strict';
	footerMenuButton.classList.remove('hidden');
	for (let footerItem of footerItems) {
		footerItem.classList.add('hidden');
		const clonedItem = footerItem.cloneNode(true);
		footerMenuList.appendChild(clonedItem);
	}
	let dropdownFooterItems = [...document.querySelectorAll('#responsive-menu-footer [data-last-responsive]')];
	for (let dropdownFooterItem of dropdownFooterItems) {
		dropdownFooterItem.classList.remove('hidden', 'nav-item');
	}
	let dropdownFooterLinks = [...document.querySelectorAll('#responsive-menu-footer > * > *')];
	for (let dropdownFooterLink of dropdownFooterLinks) {
		dropdownFooterLink.classList.remove('nav-link', 'py-0', 'px-1', 'text-body');
		dropdownFooterLink.classList.add('dropdown-item');
	}
}
function showFooterNav() {
	'use strict';
	footerMenuButton.classList.add('hidden');
	for (let footerItem of footerItems) {
		footerItem.classList.remove('hidden');
	}	
	let dropdownFooterItems = [...document.querySelectorAll('#responsive-menu-footer [data-last-responsive]')];
	for (let dropdownFooterItem of dropdownFooterItems) {
		dropdownFooterItem.remove()
	}
}
function NavSize() {
	'use strict';
    let NavBarTop = document.querySelector('.responsive-menu')
    let UserBar = document.querySelector('#user-nav')
    let emptySpaceTop = NavBarTop.clientWidth - (navigation.clientWidth + UserBar.clientWidth)
	let NavBarBottom = document.querySelector('#NavBarFooter')
	let emptySpaceBottom = NavBarBottom.clientWidth - (footerLinks.clientWidth + footerBreadcrumbs.clientWidth)
	
	if ((navigation.clientWidth + emptySpaceTop) > totalWidth) {
		showHeaderNav()
	}
	
	if (navigation.clientHeight > navFirstChildHeight ) {
		cloneHeaderNav();
	};
		
	if ((footerLinks.clientWidth + emptySpaceBottom) > totalFooterWidth) {
		showFooterNav()
	}

	if (footerLinks.clientHeight > navFirstChildHeight) {
		cloneFooterNav()
	}

}

NavSize()
window.addEventListener('resize', NavSize);
/**
* Alternate display of subPanels
*/
jQuery(function ($) {
	'use strict';

	$('.sub-panels').each(function () {

		var $childNodes = $('a[data-subpanel]', this),
			panels = $childNodes.map(function () {
				return this.getAttribute('data-subpanel');
			}),
			showPanel = this.getAttribute('data-show-panel');

		if (panels.length) {
			activateSubPanel(showPanel, panels);
			$childNodes.click(function () {
				activateSubPanel(this.getAttribute('data-subpanel'), panels);
				return false;
			});
		}
	});
});

/**
* Activate specific subPanel
*/
function activateSubPanel(p, panels) {
	'use strict';

	var i, showPanel;

	if (typeof p === 'string') {
		showPanel = p;
	}
	$('input[name="show_panel"]').val(showPanel);

	if (typeof panels === 'undefined') {
		panels = jQuery('.sub-panels a[data-subpanel]').map(function () {
			return this.getAttribute('data-subpanel');
		});
	}

	for (i = 0; i < panels.length; i++) {
		jQuery('#' + panels[i]).css('display', panels[i] === showPanel ? 'block' : 'none');
		jQuery('#' + panels[i] + '-tab').children().toggleClass('active', panels[i] === showPanel);
	}

}

function selectCode(a) {
	'use strict';

	// Get ID of code block
	var e = a.parentNode.parentNode.getElementsByTagName('CODE')[0];
	var s, r;

	// Not IE and IE9+
	if (window.getSelection) {
		s = window.getSelection();
		// Safari and Chrome
		if (s.setBaseAndExtent) {
			var l = (e.innerText.length > 1) ? e.innerText.length - 1 : 1;
			try {
				s.setBaseAndExtent(e, 0, e, l);
			} catch (error) {
				r = document.createRange();
				r.selectNodeContents(e);
				s.removeAllRanges();
				s.addRange(r);
			}
		}
		// Firefox and Opera
		else {
			// workaround for bug # 42885
			if (window.opera && e.innerHTML.substring(e.innerHTML.length - 4) === '<BR>') {
				e.innerHTML = e.innerHTML + '&nbsp;';
			}

			r = document.createRange();
			r.selectNodeContents(e);
			s.removeAllRanges();
			s.addRange(r);
		}
	}
	// Some older browsers
	else if (document.getSelection) {
		s = document.getSelection();
		r = document.createRange();
		r.selectNodeContents(e);
		s.removeAllRanges();
		s.addRange(r);
	}
	// IE
	else if (document.selection) {
		r = document.body.createTextRange();
		r.moveToElementText(e);
		r.select();
	}
}

var inAutocomplete = false;
var lastKeyEntered = '';

/**
* Check event key
*/
function phpbbCheckKey(event) {
	'use strict';

	// Keycode is array down or up?
	if (event.keyCode && (event.keyCode === 40 || event.keyCode === 38)) {
		inAutocomplete = true;
	}

	// Make sure we are not within an "autocompletion" field
	if (inAutocomplete) {
		// If return pressed and key changed we reset the autocompletion
		if (!lastKeyEntered || lastKeyEntered === event.which) {
			inAutocomplete = false;
			return true;
		}
	}

	// Keycode is not return, then return. ;)
	if (event.which !== 13) {
		lastKeyEntered = event.which;
		return true;
	}

	return false;
}

/**
* Apply onkeypress event for forcing default submit button on ENTER key press
*/
jQuery(function ($) {
	'use strict';

	$('form input[type=text], form input[type=password]').on('keypress', function (e) {
		var defaultButton = $(this).parents('form').find('input[type=submit].default-submit-action');

		if (!defaultButton || defaultButton.length <= 0) {
			return true;
		}

		if (phpbbCheckKey(e)) {
			return true;
		}

		if ((e.which && e.which === 13) || (e.keyCode && e.keyCode === 13)) {
			defaultButton.click();
			return false;
		}

		return true;
	});
});

/**
* Functions for user search popup
*/
function insertUser(formId, value) {
	'use strict';

	var $form = jQuery(formId),
		formName = $form.attr('data-form-name'),
		fieldName = $form.attr('data-field-name'),
		item = opener.document.forms[formName][fieldName];

	if (item.value.length && item.type === 'textarea') {
		value = item.value + '\n' + value;
	}

	item.value = value;
}

function insert_marked_users(formId, users) {
	'use strict';

	$(users).filter(':checked').each(function () {
		insertUser(formId, this.value);
	});

	window.close();
}

function insert_single_user(formId, user) {
	'use strict';

	insertUser(formId, user);
	window.close();
}

/**
* Parse document block
*/
function parseDocument($container) {
	'use strict';

	var test = document.createElement('div'),
		oldBrowser = (typeof test.style.borderRadius === 'undefined'),
		$body = $('body');

	/**
	* Reset avatar dimensions when changing URL or EMAIL
	*/
	$container.find('input[data-reset-on-edit]').on('keyup', function () {
		$(this.getAttribute('data-reset-on-edit')).val('');
	});

	/**
	* Pagination
	*/
	$container.find('.pagination .page-jump-form :button').click(function () {
		var $input = $(this).siblings('input.inputbox');
		pageJump($input);
	});

	$container.find('.pagination .page-jump-form input.inputbox').on('keypress', function (event) {
		if (event.which === 13 || event.keyCode === 13) {
			event.preventDefault();
			pageJump($(this));
		}
	});

	$container.find('.pagination .dropdown-trigger').click(function () {
		var $dropdownContainer = $(this).parent();
		// Wait a little bit to make sure the dropdown has activated
		setTimeout(function () {
			if ($dropdownContainer.hasClass('dropdown-visible')) {
				$dropdownContainer.find('input.inputbox').focus();
			}
		}, 100);
	});


	/**
	* Do not run functions below for old browsers
	*/
	if (oldBrowser) {
		return;
	}


	/**
	* Responsive tabs
	*/
	$container.find('#tabs, #minitabs').not('[data-skip-responsive]').each(function () {
		var $this = $(this),
			$ul = $this.children(),
			$tabs = $ul.children().not('[data-skip-responsive]'),
			$links = $tabs.children('a'),
			$item = $ul.append('<li class="tab nav-item dropdown responsive-tab nav-item" style="display:none;"><a data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" class="responsive-tab-link nav-link dropdown-toggle"></a><ul class="dropdown-menu"/></li>').find('li.responsive-tab'),
			$menu = $item.find('.dropdown-menu'),
			maxHeight = 0,
			lastWidth = false,
			responsive = false;

		$links.each(function () {
			var $this = $(this);
			maxHeight = Math.max(maxHeight, Math.max($this.outerHeight(true), $this.parent().outerHeight(true)));
		});

		function check() {
			var width = $body.width(),
				height = $this.height();

			if (!arguments.length && (!responsive || width <= lastWidth) && height <= maxHeight) {
				return;
			}

			$tabs.show();
			$item.hide();

			lastWidth = width;
			height = $this.height();
			if (height <= maxHeight) {
				if ($item.hasClass('dropdown-visible')) {
					phpbb.toggleDropdown.call($item.find('a.responsive-tab-link').get(0));
				}
				return;
			}

			responsive = true;
			$item.show();
			$menu.html('');

			var $availableTabs = $tabs.filter(':not(.activetab, .responsive-tab)'),
				total = $availableTabs.length,
				i, $tab;

			for (i = total - 1; i >= 0; i--) {
				$tab = $availableTabs.eq(i);
				$menu.prepend($tab.clone(true).removeClass('tab'));
				$tab.hide();
				if ($this.height() <= maxHeight) {
					$menu.find('a').click(function () {
						check(true);
					});
					return;
				}
			}
			$menu.find('a').click(function () {
				check(true);
			});
		}

		var $tabLink = $item.find('a.responsive-tab-link');
		phpbb.registerDropdown($tabLink, $item.find('.dropdown'), {
			visibleClass: 'activetab'
		});

		check(true);
		$(window).resize(check);
	});

	/**
	 * Hide UCP/MCP navigation if there is only 1 item
	 */
	$container.find('#navigation').each(function () {
		var $items = $(this).children('ol, ul').children('li');
		if ($items.length === 1) {
			$(this).addClass('d-none d-md-block');
		}
	});

	/**
	* Replace responsive text
	*/
	$container.find('[data-responsive-text]').each(function () {
		var $this = $(this),
			fullText = $this.text(),
			responsiveText = $this.attr('data-responsive-text'),
			responsive = false;

		function check() {
			if ($(window).width() > 700) {
				if (!responsive) {
					return;
				}
				$this.text(fullText);
				responsive = false;
				return;
			}
			if (responsive) {
				return;
			}
			$this.text(responsiveText);
			responsive = true;
		}

		check();
		$(window).resize(check);
	});
}

/**
* Run onload functions
*/
jQuery(function ($) {
	'use strict';

	// Swap .nojs and .hasjs
	$('#phpbb.nojs').toggleClass('nojs hasjs');
	$('#phpbb').toggleClass('hastouch', phpbb.isTouch);
	$('#phpbb.hastouch').removeClass('notouch');

	// Focus forms
	$('form[data-focus]:first').each(function () {
		$('#' + this.getAttribute('data-focus')).focus();
	});

	parseDocument($('body'));
});



