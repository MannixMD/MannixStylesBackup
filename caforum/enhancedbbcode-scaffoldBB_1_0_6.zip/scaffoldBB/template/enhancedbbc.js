(function ($) {

	'use strict';

	const EnhancedBBC = {

		verticalOffset: -75,
		horizontalOffset: 0,

		setCaretPosition: function (caretPos) {

			const elem = document.forms[form_name].elements[text_name];

			if (!elem) {
				return;
			}

			elem.focus();

			if (elem.setSelectionRange) {
				elem.setSelectionRange(caretPos, caretPos);
			}
		},

		showToolbox: function (title, field1, field2, callback) {

			this.hide();

			const darken = $('<div>', {
				id: 'enhancedbbc_darken',
				class: 'enhancedbbc_darken'
			});

			const popup = $('<div>', {
				id: 'enhancedbbc_popup_container',
				class: 'bg-body border'
			});

			const popupTitle = $('<h1>', {
				id: 'enhancedbbc_popup_title',
				class: 'bg-primary'
			}).text(title);

			const content = $('<div>', {
				id: 'enhancedbbc_popup_content',
				class: 'bg-body-secondary'
			});

			const field1Container = $('<div>', {
				class: 'enhancedbbc_field'
			});

			const field1Label = $('<label>', {
				class: 'enhancedbbc_label text-body'
			}).text(field1);

			const popupField1 = $('<input>', {
				type: 'text',
				id: 'enhancedbbc_popup_field1',
				class: 'inputbox form-control form-control-sm'
			});

			const field2Container = $('<div>', {
				class: 'enhancedbbc_field'
			});

			const field2Label = $('<label>', {
				class: 'enhancedbbc_label text-body'
			}).text(field2);

			const popupField2 = $('<input>', {
				type: 'text',
				id: 'enhancedbbc_popup_field2',
				class: 'inputbox form-control form-control-sm'
			});

			const panel = $('<div>', {
				id: 'enhancedbbc_popup_panel',
				class: 'border-top'
			});

			const okButton = $('<input>', {
				type: 'button',
				id: 'enhancedbbc_popup_ok',
				class: 'button2 btn btn-sm btn-primary'
			}).val(enhancedbbcLang.buttons.ok);

			const cancelButton = $('<input>', {
				type: 'button',
				id: 'enhancedbbc_popup_cancel',
				class: 'button2 btn btn-sm btn-danger'
			}).val(enhancedbbcLang.buttons.cancel);

			field1Container
				.append(field1Label)
				.append(popupField1);

			field2Container
				.append(field2Label)
				.append(popupField2);

			panel
				.append(okButton)
				.append(cancelButton);

			content
				.append(field1Container)
				.append(field2Container)
				.append(panel);

			popup
				.append(popupTitle)
				.append(content);

			$('body')
				.append(darken)
				.append(popup);

			this.reposition();

			$('#enhancedbbc_popup_field1').focus();

			if (title === enhancedbbcLang.list.title) {

				const button = $('#enhancedbbc_popup_ok');

				button.prop('disabled', true);

				const validateList = function () {

					const field1 = $('#enhancedbbc_popup_field1')
						.val()
						.trim();

					const field2 = $('#enhancedbbc_popup_field2')
						.val()
						.trim();

					button.prop(
						'disabled',
						field1 === '' || field2 === ''
					);
				};

				validateList();

				$('#enhancedbbc_popup_field1, #enhancedbbc_popup_field2')
					.on('input', validateList);
			}

			if (title === enhancedbbcLang.url.title) {

				const button = $('#enhancedbbc_popup_ok');

				button.prop('disabled', true);

				const validateUrl = function () {

					const value = $('#enhancedbbc_popup_field1')
						.val()
						.trim();

					button.prop('disabled', value === '');
				};

				validateUrl();

				$('#enhancedbbc_popup_field1')
					.on('input', validateUrl);
			}

			$('#enhancedbbc_popup_ok').on('click', function () {

				const field1 = $('#enhancedbbc_popup_field1').val().trim();
				const field2 = $('#enhancedbbc_popup_field2').val().trim();

				const isUrlPopup =
					title === enhancedbbcLang.url.title;

				if (
					isUrlPopup &&
					field1 &&
					!/^(https?|ftp):\/\//i.test(field1)
				) {

					alert(enhancedbbcLang.url.protocol);

					$('#enhancedbbc_popup_field1').focus();

					return;
				}

				EnhancedBBC.hide();

				if (callback) {
					callback(field1, field2);
				}
			});

			$('#enhancedbbc_popup_cancel').on('click', function () {

				EnhancedBBC.hide();
			});

			$('#enhancedbbc_popup_field1, #enhancedbbc_popup_field2')
				.on('keydown', function (e) {

					if (e.key === 'Enter') {
						e.preventDefault();
						$('#enhancedbbc_popup_ok').trigger('click');
					}

					if (e.key === 'Escape') {
						$('#enhancedbbc_popup_cancel').trigger('click');
					}
				});

			$(window).on('resize.enhancedbbc', function () {
				EnhancedBBC.reposition();
			});
		},

		hide: function () {

			$('#enhancedbbc_popup_container').remove();
			$('#enhancedbbc_darken').remove();

			$(window).off('resize.enhancedbbc');
		},

		reposition: function () {

			const popup = $('#enhancedbbc_popup_container');

			const top = Math.max(
				0,
				(($(window).height() / 2) - (popup.outerHeight() / 2)) + this.verticalOffset
			);

			const left = Math.max(
				0,
				(($(window).width() / 2) - (popup.outerWidth() / 2)) + this.horizontalOffset
			);

			popup.css({
				position: 'fixed',
				top: top + 'px',
				left: left + 'px'
			});
		}
	};

	window.bbfontstyle = function (bbopen, bbclose) {

		const textarea = document.forms[form_name].elements[text_name];

		if (!textarea) {
			return;
		}

		if (
			textarea.selectionEnd &&
			(textarea.selectionEnd - textarea.selectionStart > 0)
		) {
			mozWrap(textarea, bbopen, bbclose);
			return;
		}

		const caretPos = getCaretPosition(textarea).start;
		const newPos = caretPos + bbopen.length;

		if (bbopen === '[url]') {

			EnhancedBBC.showToolbox(
				enhancedbbcLang.url.title,
				enhancedbbcLang.url.link,
				enhancedbbcLang.url.text,
				function (url, title) {

					EnhancedBBC.setCaretPosition(caretPos);

					if (!title) {

						insert_text(
							'[url]' + url + '[/url]'
						);

						return;
					}

					insert_text(
						'[url=' + url + ']' + title + '[/url]'
					);
				}
			);

			return;
		}

		if (
			bbopen === '[list=]' &&
			window.enhancedbbcConfig.enableList === true
		) {

			EnhancedBBC.showToolbox(
				enhancedbbcLang.list.title,
				enhancedbbcLang.list.type,
				enhancedbbcLang.list.items,
				function (listType, itemCount) {

					if (!listType || !itemCount) {
						return;
					}

					itemCount = parseInt(itemCount, 10);

					if (isNaN(itemCount) || itemCount < 1) {
						return;
					}

					EnhancedBBC.setCaretPosition(caretPos);

					let listItems = '';

					for (let i = 0; i < itemCount; i++) {
						listItems += '[*]\n';
					}

					insert_text(
						'[list=' + listType + ']\n' +
						listItems +
						'[/list]'
					);
				}
			);

			return;
		}

		insert_text(bbopen + bbclose);

		if (!isNaN(textarea.selectionStart)) {

			textarea.selectionStart = newPos;
			textarea.selectionEnd = newPos;
		}
	};

})(jQuery);