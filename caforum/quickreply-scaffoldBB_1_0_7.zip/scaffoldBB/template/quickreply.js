document.addEventListener('DOMContentLoaded', function () {

    var qrForm = document.getElementById('qr_postform');

    if (!qrForm) {
        return;
    }

    var qrConfig = document.getElementById('qr-config');

    if (!qrConfig) {
        return;
    }

    var qrToggle = qrConfig.getAttribute('data-toggle');

    if (qrToggle !== '1') {
        return;
    }

    var qrBody = qrForm.querySelector('.panel');

    if (!qrBody) {
        return;
    }

    qrBody.classList.add('qr-body');

    var qrLang = document.getElementById('qr-lang');

    var qrShow = qrLang.getAttribute('data-show');
    var qrHide = qrLang.getAttribute('data-hide');

    var panel = document.createElement('div');

    panel.className = 'panel mb-2';
    panel.style.textAlign = 'center';

    panel.innerHTML =
        '<input type="button" class="button2 reprap btn btn-sm btn-secondary">';

    qrForm.insertBefore(panel, qrForm.firstChild);

    var button = panel.querySelector('.reprap');

    var qrState = localStorage.getItem('caforum_qr_hidden');

    if (qrState === '1') {

        qrBody.classList.add('hidden');
        button.value = qrShow;

    } else {

        button.value = qrHide;
    }

    button.addEventListener('click', function () {

        qrBody.classList.toggle('hidden');

        if (qrBody.classList.contains('hidden')) {

            button.value = qrShow;

            localStorage.setItem('caforum_qr_hidden', '1');

        } else {

            button.value = qrHide;

            localStorage.setItem('caforum_qr_hidden', '0');
        }
    });
});