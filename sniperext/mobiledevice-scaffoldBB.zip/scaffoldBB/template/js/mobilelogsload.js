$(window).on('load', function () {
	jQuery('#loading_indicator').fadeOut(3500);
});
