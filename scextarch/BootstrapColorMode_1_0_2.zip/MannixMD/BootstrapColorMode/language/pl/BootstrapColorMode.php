<?php
/** 
* 
* @package Bootstrap Color Mode
* @copyright (c) 2023 MannixMD @mannixmd
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2 
* 
*/ 
if (!defined('IN_PHPBB'))
{
exit;
}
if (empty($lang) || !is_array($lang))
{
$lang = array();
}
$lang = array_merge($lang, array(
'BCM_TOGGLE_THEME'			=> 'Zmień kolorystykę',
'BCM_LIGHT'			        => 'Jasny',
'BCM_DARK'			        => 'Ciemny',
'BCM_AUTO'				    => 'Auto',
));
