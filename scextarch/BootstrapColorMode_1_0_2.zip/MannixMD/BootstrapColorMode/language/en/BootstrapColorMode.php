<?php
/** 
* 
* @package Bootstrap Color Mode
* @copyright (c) 2023 MannixMD @mannixmd
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2 
* 
*/ 
if (!defined('IN_PHPBB'))
{
exit;
}
if (empty($lang) || !is_array($lang))
{
$lang = array();
}
$lang = array_merge($lang, array(
'BCM_TOGGLE_THEME'			=> 'Toggle theme',
'BCM_LIGHT'			        => 'Light',
'BCM_DARK'			        => 'Dark',
'BCM_AUTO'				    => 'Auto',
));
