
// COOKIES
	// Switch state
	var colorswitch = $.cookie('colorpickerHexagonReborn');
	
	// Set the user's selection    
	if (colorswitch == 'orange') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/orange.css" type="text/css" />');
	
    };
	if (colorswitch == 'green') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/green.css" type="text/css" />');
	
    };
	if (colorswitch == 'blue') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/blue.css" type="text/css" />');
    };	
	if (colorswitch == 'cyan') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/cyan.css" type="text/css" />');
    };	
	if (colorswitch == 'violet') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/violet.css" type="text/css" />');	
    };
	if (colorswitch == 'custom') {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/custom.css" type="text/css" />');	
    };	

$(document).ready(function() {
// COLORSWITCH:

	// When orange is clicked:
    $('.colororange').click(function() {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/orange.css" type="text/css" />');

		$.cookie('colorpickerHexagonReborn', 'orange', { expires: 365, path: '/' });
    });
	
	// When green is clicked:
    $('.colorgreen').click(function() {

		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/green.css" type="text/css" />');		
	
		$.cookie('colorpickerHexagonReborn', 'green', { expires: 365, path: '/' });
    });
	
	// When blue is clicked:
    $('.colorblue').click(function() {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/blue.css" type="text/css" />');

		$.cookie('colorpickerHexagonReborn', 'blue', { expires: 365, path: '/' });
    });
	
	// When cyan is clicked:
    $('.colorcyan').click(function() {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/cyan.css" type="text/css" />');

		$.cookie('colorpickerHexagonReborn', 'cyan', { expires: 365, path: '/' });
    });	
	
	// When violet is clicked:
    $('.colorviolet').click(function() {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/violet.css" type="text/css" />');

		$.cookie('colorpickerHexagonReborn', 'violet', { expires: 365, path: '/' });
    });	
	
	// When custom is clicked:
    $('.colorcustom').click(function() {
		
		$('head').append('<link rel="stylesheet" href="./styles/HexagonReborn/theme/custom.css" type="text/css" />');

		$.cookie('colorpickerHexagonReborn', 'custom', { expires: 365, path: '/' });
    });		
});