/**
 *
 * Countdown extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2024 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */
(function (window, document) {
	'use strict';

	var WEEK = 604800,
		DAY = 86400,
		HOUR = 3600,
		MINUTE = 60;

	var TOKENS = {
		'%y': 'year',
		'%m': 'month',
		'%w': 'week',
		'%d': 'day',
		'%h': 'hour',
		'%i': 'minute',
		'%s': 'second'
	};

	/**
	 * Number of days in a calendar month, read in UTC.
	 */
	function daysInMonth(year, month) {
		return new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
	}

	/**
	 * Add whole calendar months to a timestamp, clamping to the end of short
	 * months so that 31 January plus one month is 28 or 29 February, not 2 or
	 * 3 March.
	 *
	 * Timestamps here are already shifted into the display timezone, so every
	 * field is read and written in UTC. The visitor's own timezone is never
	 * consulted.
	 */
	function addMonths(timestamp, count) {
		var date = new Date(timestamp);
		var day = date.getUTCDate();
		var moved = new Date(Date.UTC(
			date.getUTCFullYear(),
			date.getUTCMonth() + count,
			1,
			date.getUTCHours(),
			date.getUTCMinutes(),
			date.getUTCSeconds()
		));

		moved.setUTCDate(Math.min(day, daysInMonth(moved.getUTCFullYear(), moved.getUTCMonth())));

		return moved.getTime();
	}

	/**
	 * Break the span between two dates into the units enabled by the settings.
	 * Years and months are counted as calendar units; the remainder is split
	 * into fixed length units.
	 */
	function split(from, to, settings) {
		var units = {year: 0, month: 0, week: 0, day: 0, hour: 0, minute: 0, second: 0};
		var cursor = from;
		var left, next;

		function take(size) {
			var count = Math.floor(left / size);
			left -= count * size;

			return count;
		}

		if (settings.years) {
			next = addMonths(cursor, 12);

			while (next <= to) {
				cursor = next;
				units.year += 1;
				next = addMonths(cursor, 12);
			}
		}

		if (settings.months) {
			next = addMonths(cursor, 1);

			while (next <= to) {
				cursor = next;
				units.month += 1;
				next = addMonths(cursor, 1);
			}
		}

		left = Math.floor((to - cursor) / 1000);

		if (settings.weeks) {
			units.week = take(WEEK);
		}

		units.day = take(DAY);
		units.hour = take(HOUR);
		units.minute = take(MINUTE);
		units.second = take(1);

		return units;
	}

	/**
	 * Substitute the unit placeholders in the format string.
	 */
	function render(units, settings) {
		return settings.format.replace(/%[ymwdhis]/g, function (token) {
			var unit = TOKENS[token];
			var value, pair;

			if (!unit) {
				return '';
			}

			if (unit === 'year' && !settings.years) {
				return '';
			}

			if (unit === 'month' && !settings.months) {
				return '';
			}

			if (unit === 'week' && !settings.weeks) {
				return '';
			}

			value = units[unit];
			pair = settings.labels[unit] || ['', ''];

			return (settings.leadingZero && value < 10 ? '0' + value : String(value)) + ' ' + (value === 1 ? pair[0] : pair[1]) + ' ';
		});
	}

	/**
	 * Wrap the rendered units in the admin supplied surrounding text.
	 *
	 * The text is kept out of the format string so that a literal %d, %s or
	 * any other unit token inside it is never mistaken for a placeholder.
	 */
	function decorate(body, settings) {
		return settings.prefix + body + settings.suffix;
	}

	/**
	 * A clock anchored on the server's instant.
	 *
	 * Only elapsed time is read from the browser, never its wall clock, so a
	 * device with an incorrect date or time still counts down correctly.
	 * performance.now() is monotonic and is unaffected by clock adjustments.
	 */
	function serverClock(serverNow) {
		var monotonic = !!(window.performance && typeof window.performance.now === 'function');
		var origin = monotonic ? window.performance.now() : Date.now();

		return function () {
			var elapsed = (monotonic ? window.performance.now() : Date.now()) - origin;

			return serverNow + elapsed;
		};
	}

	/**
	 * Start a countdown on an element.
	 */
	function start(options) {
		var element = typeof options.element === 'string' ? document.getElementById(options.element) : options.element;
		var target = Number(options.target);
		var settings, timer, clock;

		if (!element || !target || isNaN(target)) {
			return;
		}

		clock = serverClock(Number(options.now) || Date.now());

		settings = {
			direction: options.direction === 'up' ? 'up' : 'down',
			offset: typeof options.offset === 'number' ? options.offset : 0,
			leadingZero: !!options.leadingZero,
			years: !!options.years,
			months: !!options.months,
			weeks: !!options.weeks,
			format: options.format || '%d %h %i %s',
			prefix: options.prefix || '',
			suffix: options.suffix || '',
			labels: options.labels || {},
			completeHtml: options.completeHtml || ''
		};

		function tick() {
			// Both timestamps are shifted by the same amount, so the remaining
			// time is unaffected; the shift only puts calendar fields into the
			// display timezone.
			var now = (Math.floor(clock() / 1000) * 1000) + settings.offset;
			var goal = target + settings.offset;
			var from = settings.direction === 'down' ? now : goal;
			var to = settings.direction === 'down' ? goal : now;

			if (to - from <= 0) {
				if (settings.direction === 'down') {
					element.innerHTML = settings.completeHtml || decorate(render(split(to, to, settings), settings), settings);

					return true;
				}

				// Counting up has not started yet. Show zeros and keep the
				// timer running so the count begins on its own once the
				// start date is reached.
				element.innerHTML = decorate(render(split(goal, goal, settings), settings), settings);

				return false;
			}

			element.innerHTML = decorate(render(split(from, to, settings), settings), settings);

			return false;
		}

		function schedule() {
			timer = window.setTimeout(function () {
				if (tick()) {
					window.clearTimeout(timer);

					return;
				}

				schedule();
			}, 1000 - (clock() % 1000));
		}

		if (!tick()) {
			schedule();
		}
	}

	/**
	 * Resolve the element an entry points at, without starting it.
	 */
	function resolve(options) {
		return typeof options.element === 'string' ? document.getElementById(options.element) : options.element;
	}

	/**
	 * Start every queued countdown whose element is already in the document.
	 *
	 * The countdown markup is rendered above this script, so the queue is
	 * drained straight away rather than waiting for DOMContentLoaded, which
	 * would leave the element empty for as long as the rest of the page takes
	 * to parse. Entries whose element is not there yet are left in the queue.
	 */
	function drain() {
		var queue = window.stokerCountdownQueue || (window.stokerCountdownQueue = []);
		var i = 0;

		while (i < queue.length) {
			if (resolve(queue[i])) {
				start(queue[i]);
				queue.splice(i, 1);

				continue;
			}

			i += 1;
		}
	}

	drain();

	// Entries whose element was not in the document yet are retried once the
	// rest of the page is available, whatever state the document was in when
	// this script ran.
	if (window.stokerCountdownQueue.length) {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', drain);
		} else if (document.readyState === 'complete') {
			window.setTimeout(drain, 0);
		} else {
			window.addEventListener('load', drain);
		}
	}

	window.stokerCountdown = start;
})(window, document);
