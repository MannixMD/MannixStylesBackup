/*
	Top Stats extension for the phpBB Forum Software package.

	Vanilla JS vertical ticker. Replaces the jQuery totemticker plugin.
	No external dependencies. Animates with a CSS transform/transition
	instead of jQuery's margin-top .animate(), so the browser compositor
	drives the motion instead of a JS timer loop.

	@copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
	@license GNU General Public License, version 2 (GPL-2.0)
*/
(function () {
	'use strict';

	// Feature-detect passive listener support so touch handlers don't
	// accidentally run in the capture phase on very old browsers that
	// coerce a third-argument object to a truthy "useCapture" boolean.
	var supportsPassive = false;
	try {
		var testOpts = Object.defineProperty({}, 'passive', {
			get: function () {
				supportsPassive = true;
			}
		});
		window.addEventListener('ts-ticker-test', null, testOpts);
		window.removeEventListener('ts-ticker-test', null, testOpts);
	} catch (e) {
		supportsPassive = false;
	}

	var passiveListener = supportsPassive ? { passive: true } : false;

	/**
	 * @param {HTMLElement} el Ticker container (a <ul>)
	 * @param {Object} options
	 */
	function TopstatsTicker(el, options) {
		this.el = el;
		this.options = extend({
			maxItems: null,
			speed: 400,
			interval: 4000,
			mousestop: true,
			direction: 'up',
			autoStart: true,
			pauseOnHidden: true,
			next: null,
			previous: null,
			stop: null,
			start: null
		}, options || {});

		this.timer = null;
		this.paused = false;
		this.hovered = false;
		this.busy = false;
		this.rowHeight = 0;

		this.reducedMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

		this.init();
	}

	function toArray(collection) {
		return Array.prototype.slice.call(collection);
	}

	function extend(base, extra) {
		var out = {};
		var key;
		for (key in base) {
			if (Object.prototype.hasOwnProperty.call(base, key)) {
				out[key] = base[key];
			}
		}
		for (key in extra) {
			if (Object.prototype.hasOwnProperty.call(extra, key)) {
				out[key] = extra[key];
			}
		}
		return out;
	}

	TopstatsTicker.prototype.init = function () {
		if (this.reducedMotion) {
			// Defensive fallback if this is ever instantiated without the
			// caller already checking prefers-reduced-motion itself.
			this.options.speed = Math.max(this.options.speed, 1200);
			this.options.interval = Math.max(this.options.interval, 8000);
		}

		this.measureRowHeight();
		this.formatTicker();
		this.setupNav();
		this.bindLifecycleEvents();

		if (this.options.autoStart !== false && !this.reducedMotion) {
			this.startInterval();
		}
	};

	TopstatsTicker.prototype.measureRowHeight = function () {
		var first = this.el.firstElementChild;
		// Round to a whole pixel - a fractional offset (e.g. 41.83px) can get
		// rounded slightly differently between plain text and icon-font
		// glyphs, showing up as a 1px mismatch between them once settled.
		this.rowHeight = first ? Math.round(first.getBoundingClientRect().height) : 0;
	};

	/**
	 * The rows a step actually needs to touch: the visible slots plus the
	 * one row entering from off-screen. Rows further down the list stay
	 * clipped by overflow:hidden the entire time regardless of whether
	 * they get transformed, so there's no reason to move them - doing so
	 * anyway was needless transform/transition work on boards with a
	 * large configured item count.
	 *
	 * @return {Element[]}
	 */
	TopstatsTicker.prototype.animatedChildren = function () {
		var all = toArray(this.el.children);
		if (!this.options.maxItems) {
			return all;
		}
		return all.slice(0, Math.min(all.length, this.options.maxItems + 1));
	};

	TopstatsTicker.prototype.formatTicker = function () {
		if (this.options.maxItems && this.rowHeight) {
			this.el.style.height = (this.rowHeight * this.options.maxItems) + 'px';
		}
		this.el.style.overflow = 'hidden';
		this.el.setAttribute('role', 'list');

		var items = this.el.children;
		for (var i = 0; i < items.length; i++) {
			items[i].setAttribute('role', 'listitem');
		}
	};

	TopstatsTicker.prototype.setupNav = function () {
		var self = this;

		function wire(node, handler) {
			if (!node) {
				return;
			}
			if (!node.hasAttribute('tabindex')) {
				node.setAttribute('tabindex', '0');
			}
			node.setAttribute('role', 'button');
			node.addEventListener('click', function (e) {
				e.preventDefault();
				handler();
			});
			node.addEventListener('keydown', function (e) {
				if (e.key === ' ' || e.key === 'Enter' || e.key === 'Spacebar') {
					e.preventDefault();
					handler();
				}
			});
		}

		wire(this.options.stop, function () {
			self.pauseManual();
		});
		wire(this.options.start, function () {
			self.startInterval();
		});
		wire(this.options.previous, function () {
			if (self.stepPrevious()) {
				self.resetInterval();
			}
		});
		wire(this.options.next, function () {
			if (self.stepNext()) {
				self.resetInterval();
			}
		});
	};

	TopstatsTicker.prototype.bindLifecycleEvents = function () {
		var self = this;

		if (this.options.mousestop) {
			this.el.addEventListener('mouseenter', function () {
				self.hovered = true;
				self.stopInterval();
			});
			this.el.addEventListener('mouseleave', function () {
				self.hovered = false;
				if (!self.paused && !self.reducedMotion) {
					self.startInterval();
				}
			});

			// Touch devices don't fire mouseenter/mouseleave reliably, so a
			// finger resting on the ticker (e.g. reading, or about to tap a
			// nav button) gets the same "pause while interacting" treatment.
			this.el.addEventListener('touchstart', function () {
				self.hovered = true;
				self.stopInterval();
			}, passiveListener);
			this.el.addEventListener('touchend', function () {
				self.hovered = false;
				if (!self.paused && !self.reducedMotion) {
					self.startInterval();
				}
			}, passiveListener);
		}

		this.el.addEventListener('focusin', function () {
			self.stopInterval();
		});
		this.el.addEventListener('focusout', function () {
			if (!self.paused && !self.hovered && !self.reducedMotion) {
				self.startInterval();
			}
		});

		if (this.options.pauseOnHidden !== false && typeof document !== 'undefined') {
			document.addEventListener('visibilitychange', function () {
				if (document.hidden) {
					self.stopInterval();
				} else if (!self.paused && !self.hovered && !self.reducedMotion) {
					self.startInterval();
				}
			});
		}
	};

	TopstatsTicker.prototype.startInterval = function () {
		this.stopInterval();
		if (this.options.interval <= 0) {
			return;
		}
		var self = this;
		var step = this.options.direction === 'up' ? this.stepPrevious : this.stepNext;
		this.timer = window.setInterval(function () {
			step.call(self);
		}, this.options.interval);
		this.paused = false;
	};

	TopstatsTicker.prototype.stopInterval = function () {
		if (this.timer) {
			window.clearInterval(this.timer);
			this.timer = null;
		}
	};

	TopstatsTicker.prototype.pauseManual = function () {
		this.stopInterval();
		this.paused = true;
	};

	TopstatsTicker.prototype.resetInterval = function () {
		this.stopInterval();
		this.startInterval();
	};

	/**
	 * Move the last row to the front, then slide EVERY row down by one
	 * slot together (the last row enters from above, the rest shift down
	 * and the previously-last-visible row is pushed out the bottom).
	 * Used for the "previous" control and for auto-play direction "up".
	 *
	 * Rows are transformed as a uniform set rather than individually,
	 * because unlike margin-top (which the old jQuery version animated),
	 * transform does not affect document flow - animating only the
	 * entering/exiting row would leave the other visible rows static.
	 *
	 * @return {boolean} Whether a step was actually started
	 */
	TopstatsTicker.prototype.stepPrevious = function () {
		if (this.busy || !this.rowHeight) {
			return false;
		}
		var last = this.el.lastElementChild;
		if (!last || last === this.el.firstElementChild) {
			return false;
		}

		var self = this;
		var rowHeight = this.rowHeight;
		this.busy = true;
		this.el.setAttribute('aria-busy', 'true');

		// Reorder first: normal flow now pushes every other row down by
		// one slot automatically. The instant offset below counteracts
		// that so nothing visibly jumps before the transition starts.
		this.el.insertBefore(last, this.el.firstElementChild);

		var children = this.animatedChildren();

		children.forEach(function (child) {
			child.style.transition = 'none';
			child.style.transform = 'translateY(-' + rowHeight + 'px)';
		});
		// Force a reflow so the instant offset above is committed before
		// the transitioned move below starts, instead of both being batched.
		void this.el.offsetHeight;

		this.onTransitionEndOnce(children[0], function () {
			self.finishStep(children);
		});

		var transitionStr = 'transform ' + this.options.speed + 'ms ease';
		children.forEach(function (child) {
			child.style.transition = transitionStr;
			child.style.transform = 'translateY(0)';
		});

		return true;
	};

	/**
	 * Slide EVERY row up by one slot together (the first row exits at the
	 * top, the rest shift up and a hidden row below enters at the bottom),
	 * then move the exited row to the back of the list.
	 * Used for the "next" control and for auto-play direction "down".
	 *
	 * @return {boolean} Whether a step was actually started
	 */
	TopstatsTicker.prototype.stepNext = function () {
		if (this.busy || !this.rowHeight) {
			return false;
		}
		if (this.el.children.length < 2) {
			return false;
		}

		var self = this;
		var rowHeight = this.rowHeight;
		var children = this.animatedChildren();
		var exiting = children[0];
		this.busy = true;
		this.el.setAttribute('aria-busy', 'true');

		var transitionStr = 'transform ' + this.options.speed + 'ms ease';
		children.forEach(function (child) {
			child.style.transition = transitionStr;
			child.style.transform = 'translateY(-' + rowHeight + 'px)';
		});

		this.onTransitionEndOnce(exiting, function () {
			// Move the exited row to the back before resetting transforms,
			// so the browser paints the settled end state directly with
			// no flicker (see finishStep).
			self.el.appendChild(exiting);
			self.finishStep(children);
		});

		return true;
	};

	/**
	 * Shared step-completion cleanup: instantly reset every row's
	 * transition/transform in one synchronous pass (with a forced reflow
	 * in between so the reset itself doesn't animate), then clear the
	 * busy state.
	 *
	 * @param {Element[]} children Rows that were part of the step
	 */
	TopstatsTicker.prototype.finishStep = function (children) {
		children.forEach(function (child) {
			child.style.transition = 'none';
			child.style.transform = '';
		});
		void this.el.offsetHeight;
		children.forEach(function (child) {
			child.style.transition = '';
		});
		this.busy = false;
		this.el.removeAttribute('aria-busy');
	};

	TopstatsTicker.prototype.onTransitionEndOnce = function (node, callback) {
		var done = false;
		var fallback;

		function finish() {
			if (done) {
				return;
			}
			done = true;
			node.removeEventListener('transitionend', onEnd);
			window.clearTimeout(fallback);
			callback();
		}

		function onEnd(e) {
			if (e.target === node && e.propertyName === 'transform') {
				finish();
			}
		}

		node.addEventListener('transitionend', onEnd);
		// Safety net: some browsers/contexts (backgrounded tabs, display:none
		// ancestors) never fire transitionend. Don't let the ticker jam.
		fallback = window.setTimeout(finish, this.options.speed + 150);
	};

	window.TopstatsTicker = TopstatsTicker;
})();
