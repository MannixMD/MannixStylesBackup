/**
 *
 * Forum SEO. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2025, Stoker, https://phpbb3bbcodes.com
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

(function () {
	'use strict';

	function buildLinks(container) {
		var url = container.getAttribute('data-share-url') || '';
		var title = container.getAttribute('data-share-title') || '';

		if (!url) {
			return;
		}

		var eUrl = encodeURIComponent(url);
		var eTitle = encodeURIComponent(title);
		var eBoth = encodeURIComponent((title ? title + ' ' : '') + url);

		var map = {
			facebook: 'https://www.facebook.com/sharer/sharer.php?u=' + eUrl,
			x: 'https://twitter.com/intent/tweet?url=' + eUrl + '&text=' + eTitle,
			bluesky: 'https://bsky.app/intent/compose?text=' + eBoth,
			linkedin: 'https://www.linkedin.com/sharing/share-offsite/?url=' + eUrl,
			reddit: 'https://www.reddit.com/submit?url=' + eUrl + '&title=' + eTitle,
			pinterest: 'https://pinterest.com/pin/create/button/?url=' + eUrl + '&description=' + eTitle,
			tumblr: 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' + eUrl + '&caption=' + eTitle,
			whatsapp: 'https://api.whatsapp.com/send?text=' + eBoth,
			email: 'mailto:?subject=' + eTitle + '&body=' + eUrl
		};

		var links = container.querySelectorAll('.forumseo-share-net');
		Array.prototype.forEach.call(links, function (link) {
			var net = link.getAttribute('data-net');
			if (map[net]) {
				link.setAttribute('href', map[net]);
			}
		});
	}

	function closeAll(except) {
		var open = document.querySelectorAll('.forumseo-share-menu:not([hidden])');
		Array.prototype.forEach.call(open, function (menu) {
			if (menu !== except) {
				menu.setAttribute('hidden', 'hidden');
				var toggle = menu.parentNode.querySelector('.forumseo-share-toggle');
				if (toggle) {
					toggle.setAttribute('aria-expanded', 'false');
				}
			}
		});
	}

	function initContainer(container) {
		var toggle = container.querySelector('.forumseo-share-toggle');
		var menu = container.querySelector('.forumseo-share-menu');
		var copyBtn = container.querySelector('.forumseo-share-copy-btn');
		var urlInput = container.querySelector('.forumseo-share-url');

		if (!toggle || !menu) {
			return;
		}

		buildLinks(container);

		toggle.addEventListener('click', function (e) {
			e.preventDefault();
			var isHidden = menu.hasAttribute('hidden');
			closeAll(isHidden ? menu : null);

			if (isHidden) {
				menu.removeAttribute('hidden');
				toggle.setAttribute('aria-expanded', 'true');
			} else {
				menu.setAttribute('hidden', 'hidden');
				toggle.setAttribute('aria-expanded', 'false');
			}
		});

		if (copyBtn && urlInput) {
			var icon = copyBtn.querySelector('.icon');
			var originalLabel = copyBtn.getAttribute('aria-label') || '';
			var copiedLabel = copyBtn.getAttribute('data-copied-label') || originalLabel;

			copyBtn.addEventListener('click', function () {
				var value = urlInput.value;
				var done = function () {
					if (icon) {
						icon.classList.remove('fa-copy');
						icon.classList.add('fa-check');
					}
					copyBtn.setAttribute('aria-label', copiedLabel);
					copyBtn.setAttribute('title', copiedLabel);
					setTimeout(function () {
						if (icon) {
							icon.classList.remove('fa-check');
							icon.classList.add('fa-copy');
						}
						copyBtn.setAttribute('aria-label', originalLabel);
						copyBtn.setAttribute('title', originalLabel);
					}, 2000);
				};
				var fallback = function () {
					urlInput.focus();
					urlInput.select();
					try {
						document.execCommand('copy');
					} catch (err) {
						// Copy not supported; user can still select manually
					}
					done();
				};

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(value).then(done).catch(fallback);
				} else {
					fallback();
				}
			});
		}
	}

	function init() {
		var containers = document.querySelectorAll('.forumseo-share');
		Array.prototype.forEach.call(containers, initContainer);

		document.addEventListener('click', function (e) {
			if (!(e.target.closest && e.target.closest('.forumseo-share'))) {
				closeAll(null);
			}
		});

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.keyCode === 27) {
				closeAll(null);
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();