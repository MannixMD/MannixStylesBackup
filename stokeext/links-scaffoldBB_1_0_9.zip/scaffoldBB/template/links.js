/**
 *
 * Partner Links extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2026 stoker - https://phpbb3bbcodes.com/
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

(function() {
	'use strict';

	function flash(button) {
		if (button.classList.contains('links-copied')) {
			return;
		}

		var label = button.getAttribute('data-copied');
		var title = button.getAttribute('title');
		var markup = button.innerHTML;

		button.classList.add('links-copied','btn-success');
		button.setAttribute('title', label);
		button.innerHTML = '<i class="icon fa fa-check fa-fw" aria-hidden="true"></i>';
		button.appendChild(document.createTextNode(label));

		window.setTimeout(function() {
			button.classList.remove('links-copied','btn-success');
			button.setAttribute('title', title);
			button.innerHTML = markup;
		}, 1500);
	}

	function legacyCopy(field, button) {
		field.removeAttribute('readonly');
		field.select();
		field.setSelectionRange(0, field.value.length);

		try {
			if (document.execCommand('copy')) {
				flash(button);
			}
		} catch (e) {
			// Nothing to do, the value stays selected for a manual copy
		}

		field.setAttribute('readonly', 'readonly');
	}

	document.addEventListener('click', function(e) {
		var button = e.target.closest ? e.target.closest('.links-copy') : null;

		if (!button) {
			return;
		}

		e.preventDefault();

		var field = document.getElementById(button.getAttribute('data-copy-target'));

		if (!field) {
			return;
		}

		// navigator.clipboard is unavailable on boards served over plain HTTP
		if (window.navigator.clipboard && window.isSecureContext) {
			window.navigator.clipboard.writeText(field.value).then(function() {
				flash(button);
			}, function() {
				legacyCopy(field, button);
			});

			return;
		}

		legacyCopy(field, button);
	});
})();
