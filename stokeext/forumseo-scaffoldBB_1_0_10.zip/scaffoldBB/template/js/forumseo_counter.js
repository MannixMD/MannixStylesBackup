(function() {
	var textarea = document.getElementById('topic_meta_desc');
	var counter = document.getElementById('topic_meta_desc_counter');

	function updateCounter() {
		var length = textarea.value.length;
		counter.textContent = length + ' / 160';
		counter.style.color = length <= 120 ? '#2E7D32' : length <= 150 ? '#F57C00' : '#BC2A4D';
	}

	textarea.addEventListener('input', updateCounter);
	updateCounter();
})();
