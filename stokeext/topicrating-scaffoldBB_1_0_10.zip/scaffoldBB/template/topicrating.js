/**
 *
 * Topic Rating. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2025 Stoker
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */
(function ($) {
	'use strict';

	var $loadingIndicator = null;

	function showLoadingIndicator() {
		if (typeof phpbb !== 'undefined' && typeof phpbb.loadingIndicator === 'function') {
			$loadingIndicator = phpbb.loadingIndicator();
		}
	}

	function hideLoadingIndicator() {
		if ($loadingIndicator && $loadingIndicator.is(':visible')) {
			$loadingIndicator.fadeOut(
				(typeof phpbb !== 'undefined' && phpbb.alertTime) ? phpbb.alertTime : 300
			);
		}
	}

	// phpbb.confirm() only injects the given HTML into .alert_text - it does not
	// render any buttons itself. The Yes/No buttons only exist in core because
	// confirm_box()/confirm_body.html bake them into the server-rendered message.
	// This replicates that exact markup (title, name="confirm"/"cancel", .button2)
	// so phpbb.confirm()'s own click handler has something to bind to.
	function buildConfirmMessage(title, text) {
		return '<h3>' + title + '</h3>' +
			'<p>' + text + '</p>' +
			'<fieldset class="submit-buttons">' +
			'<input type="button" name="confirm" value="' + ratingLang.yes + '" class="button2">&nbsp;' +
			'<input type="button" name="cancel" value="' + ratingLang.no + '" class="button2">' +
			'</fieldset>';
	}

	var topicRating = {

		init: function () {
			this.bindStarRating();
			this.bindUpDownVotes();
			this.bindRemoveLinks();
			this.bindModDelete();
		},

		// Generate light fingerprint from browser characteristics
		generateFingerprint: function () {
			var components = [
				navigator.userAgent || '',
				screen.width + 'x' + screen.height,
				screen.colorDepth || '',
				new Date().getTimezoneOffset(),
				navigator.language || navigator.userLanguage || '',
				(navigator.platform || '')
			];

			var str = components.join('|');

			function hashSeed(s, seed) {
				var h = seed >>> 0;
				for (var i = 0; i < s.length; i++) {
					h = (h ^ s.charCodeAt(i)) >>> 0;
					h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
				}
				return ('00000000' + h.toString(16)).slice(-8);
			}

			return (
				hashSeed(str, 0x811c9dc5) +
				hashSeed(str, 0x01000193) +
				hashSeed(str, 0xdeadbeef) +
				hashSeed(str, 0x9e3779b1)
			);
		},

		bindStarRating: function () {
			var self = this;

			$('.rating-stars').each(function () {
				var $stars = $(this);
				var $filled = $stars.find('.stars-filled');
				var $container = $stars.closest('.topic-rating-container');

				if (!$container.length) {
					return;
				}

				// Check if this is a profile or topic
				var entityType = $container.data('entity-type');
				var hasId = entityType === 'profile' ? $container.data('user-id') : $container.data('topic-id');
				
				if (!hasId) {
					return;
				}

				var canRate = $container.data('can-rate');
				if (!canRate) {
					return;
				}

				$stars.on('mousemove', function (e) {
					if ($container.hasClass('loading')) {
						return;
					}

					var rating = self.getRatingFromMouse(e, $stars);
					$filled.css('width', (rating * 20) + '%');
				});

				$stars.on('mouseleave', function () {
					var $container = $stars.closest('.topic-rating-container');
					var avgPercentage = parseFloat($container.data('avg-percentage')) || 0;
					$filled.css('width', avgPercentage + '%');
				});

				$stars.on('click', function (e) {
					e.preventDefault();

					if ($container.hasClass('loading')) {
						return;
					}

					var rating = self.getRatingFromMouse(e, $stars);
					var entityType = $container.data('entity-type');
					
					if (entityType === 'profile') {
						var userId = $container.data('user-id');
						self.submitProfileRating(userId, rating, $container);
					} else {
						var topicId = $container.data('topic-id');
						self.submitRating(topicId, rating, $container);
					}
				});
			});
		},

		bindUpDownVotes: function () {
			var self = this;

			$(document).on('click', '.minivote', function (e) {
				e.preventDefault();
				e.stopPropagation();

				var $btn = $(this);
				var $container = $btn.closest('.topic-rating-container');

				if (!$container.length || $container.hasClass('loading') || $btn.hasClass('vote-disabled')) {
					return;
				}

				var vote = parseInt($btn.data('vote'), 10);
				var current = parseInt($container.data('user-rating'), 10);
				var allowRevote = $container.data('allow-revote');
				var entityType = $container.data('entity-type');

				if (current === vote && !allowRevote) {
					phpbb.alert('', ratingLang.alreadyVoted);
					return;
				}

				if (current !== 0 && current !== vote && !allowRevote) {
					phpbb.alert('', ratingLang.alreadyVoted);
					return;
				}

				// Route to correct submit function based on entity type
				if (entityType === 'profile') {
					var userId = $container.data('user-id');
					self.submitProfileRating(userId, vote, $container);
				} else {
					var topicId = $container.data('topic-id');
					self.submitRating(topicId, vote, $container);
				}
			});
		},

		bindRemoveLinks: function () {
			var self = this;

			$(document).on('click', '.rating-remove-link', function (e) {
				e.preventDefault();
				
				var $link = $(this);
				var $container = $link.closest('.panel').find('.topic-rating-container');
				
				if (!$container.length || $container.hasClass('loading')) {
					return;
				}
				
				var entityType = $container.data('entity-type');
				var removeHash = $link.data('remove-hash');
				
				// No confirmation - just remove it
				if (entityType === 'profile') {
					var userId = $container.data('user-id');
					self.removeProfileRating(userId, removeHash, $container);
				} else {
					var topicId = $container.data('topic-id');
					self.removeTopicRating(topicId, removeHash, $container);
				}
			});
		},

		bindModDelete: function () {
			var self = this;

			$(document).on('click', '.rating-mod-delete-link', function (e) {
				e.preventDefault();

				var $btn = $(this);
				var $container = $btn.closest('.panel').find('.topic-rating-container');

				if (!$container.length || $container.hasClass('loading')) {
					return;
				}

				var entityType = $container.data('entity-type');
				var clearHash = $btn.data('clear-hash');

				// First confirmation
				var title = entityType === 'profile' ? ratingLang.modDeleteProfileTitle : ratingLang.modDeleteTopicTitle;
				var confirm1 = entityType === 'profile' ? ratingLang.modDeleteProfileConfirm1 : ratingLang.modDeleteTopicConfirm1;

				phpbb.confirm(buildConfirmMessage(title, confirm1), function (del1) {
					if (!del1) {
						return;
					}

					// Second confirmation. phpbb.confirm() reuses a single shared dialog
					// (#phpbb_confirm) and only supports one open confirm box at a time, so
					// this must wait until the first dialog's own close/cleanup has run -
					// calling it synchronously here gets its click handler unbound and the
					// dialog closed immediately by the outer handler's cleanup.
					setTimeout(function () {
						phpbb.confirm(buildConfirmMessage(title, ratingLang.modDeleteConfirm2), function (del2) {
							if (!del2) {
								return;
							}

							if (entityType === 'profile') {
								var userId = $container.data('user-id');
								self.clearProfileRatings(userId, clearHash, $btn, $container);
							} else {
								var topicId = $container.data('topic-id');
								self.clearTopicRatings(topicId, clearHash, $btn, $container);
							}
						});
					}, phpbb.alertTime);
				});
			});
		},

		getRatingFromMouse: function (e, $stars) {
			var offset = $stars.offset().left;
			var width = $stars.outerWidth();
			var x = e.pageX - offset;

			var percent = x / width;
			var rating = Math.ceil(percent * 5);

			return Math.min(Math.max(rating, 1), 5);
		},

		submitRating: function (topicId, rating, $container) {
			var self = this;
			var hash = $container.data('hash');
			var fingerprint = this.generateFingerprint();

			// Check localStorage for guest users
			if (typeof(Storage) !== 'undefined') {
				var storageKey = 'topic_rating_' + topicId;
				var storedRating = localStorage.getItem(storageKey);
				var allowRevote = $container.data('allow-revote');

				if (storedRating && !allowRevote) {
					return; // Silently prevent duplicate voting
				}
			}

			$container.addClass('loading');
			showLoadingIndicator();

			$.ajax({
				url: ratingUrls.topicRate,
				type: 'POST',
				dataType: 'json',
				data: {
					topic_id: topicId,
					rating: rating,
					hash: hash,
					fingerprint: fingerprint
				},
				success: function (response) {
					if (response && response.success) {
						// Store in localStorage for guests
						if (ratingIsGuest && typeof(Storage) !== 'undefined') {
							localStorage.setItem('topic_rating_' + topicId, rating);
						}
						self.updateDisplay($container, response);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.errorSubmitting;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		submitProfileRating: function (userId, rating, $container) {
			var self = this;
			var hash = $container.data('hash');
			var fingerprint = this.generateFingerprint();

			// Check localStorage for guest users
			if (typeof(Storage) !== 'undefined') {
				var storageKey = 'profile_rating_' + userId;
				var storedRating = localStorage.getItem(storageKey);
				var allowRevote = $container.data('allow-revote');

				if (storedRating && !allowRevote) {
					phpbb.alert('', ratingLang.alreadyRatedProfile);
					return;
				}
			}

			$container.addClass('loading');
			showLoadingIndicator();

			$.ajax({
				url: ratingUrls.profileRate,
				type: 'POST',
				dataType: 'json',
				data: {
					user_id: userId,
					rating: rating,
					hash: hash,
					fingerprint: fingerprint
				},
				success: function (response) {
					if (response && response.success) {
						// Store in localStorage for guests
						if (ratingIsGuest && typeof(Storage) !== 'undefined') {
							localStorage.setItem('profile_rating_' + userId, rating);
						}
						self.updateDisplay($container, response);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.errorSubmitting;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		removeTopicRating: function (topicId, hash, $container) {
			var self = this;
			
			$container.addClass('loading');
			showLoadingIndicator();
			
			$.ajax({
				url: ratingUrls.topicRemove,
				type: 'POST',
				dataType: 'json',
				data: {
					topic_id: topicId,
					hash: hash,
					fingerprint: this.generateFingerprint()
				},
				success: function (response) {
					if (response && response.success && response.removed) {
						// Remove from localStorage
						if (typeof(Storage) !== 'undefined') {
							localStorage.removeItem('topic_rating_' + topicId);
						}
						
						// Update rating hash for re-voting
						if (response.rate_hash) {
							$container.data('hash', response.rate_hash);
						}
						
						self.updateDisplay($container, response);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.error;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		removeProfileRating: function (userId, hash, $container) {
			var self = this;
			
			$container.addClass('loading');
			showLoadingIndicator();
			
			$.ajax({
				url: ratingUrls.profileRemove,
				type: 'POST',
				dataType: 'json',
				data: {
					user_id: userId,
					hash: hash,
					fingerprint: this.generateFingerprint()
				},
				success: function (response) {
					if (response && response.success && response.removed) {
						// Remove from localStorage
						if (typeof(Storage) !== 'undefined') {
							localStorage.removeItem('profile_rating_' + userId);
						}
						
						// Update rating hash for re-voting
						if (response.rate_hash) {
							$container.data('hash', response.rate_hash);
						}
						
						self.updateDisplay($container, response);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.error;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		clearTopicRatings: function (topicId, hash, $btn, $container) {
			var self = this;

			$container.addClass('loading');
			showLoadingIndicator();

			$.ajax({
				url: ratingUrls.topicClear,
				type: 'POST',
				dataType: 'json',
				data: {
					topic_id: topicId,
					hash: hash
				},
				success: function (response) {
					if (response && response.success) {
						// Clear localStorage for the current user
						if (typeof(Storage) !== 'undefined') {
							localStorage.removeItem('topic_rating_' + topicId);
						}

						// Update hashes for future interactions
						if (response.rate_hash) {
							$container.data('hash', response.rate_hash);
						}
						if (response.clear_hash) {
							$btn.data('clear-hash', response.clear_hash);
						}

						// Hide trash icon - no ratings remain
						$btn.hide();

						self.updateDisplay($container, response);
						phpbb.alert('', ratingLang.modDeleteTopicSuccess);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.error;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		clearProfileRatings: function (userId, hash, $btn, $container) {
			var self = this;

			$container.addClass('loading');
			showLoadingIndicator();

			$.ajax({
				url: ratingUrls.profileClear,
				type: 'POST',
				dataType: 'json',
				data: {
					user_id: userId,
					hash: hash
				},
				success: function (response) {
					if (response && response.success) {
						// Clear localStorage for the current user
						if (typeof(Storage) !== 'undefined') {
							localStorage.removeItem('profile_rating_' + userId);
						}

						// Update hashes for future interactions
						if (response.rate_hash) {
							$container.data('hash', response.rate_hash);
						}
						if (response.clear_hash) {
							$btn.data('clear-hash', response.clear_hash);
						}

						// Hide trash icon - no ratings remain
						$btn.hide();

						self.updateDisplay($container, response);
						phpbb.alert('', ratingLang.modDeleteProfileSuccess);
					} else {
						phpbb.alert('', response.error || ratingLang.error);
					}
				},
				error: function (xhr) {
					var errorMsg = ratingLang.error;
					if (xhr.responseJSON && xhr.responseJSON.error) {
						errorMsg = xhr.responseJSON.error;
					}
					phpbb.alert('', errorMsg);
				},
				complete: function () {
					$container.removeClass('loading');
					hideLoadingIndicator();
				}
			});
		},

		updateDisplay: function ($container, data) {
			var ratingMode = $container.data('rating-mode');
			var $stars = $container.find('.rating-stars');
			var $text = $container.find('.rating-text');

			if (ratingMode == 1 && $stars.length) {
				$stars.find('.stars-filled')
					.css('width', data.rating_percentage + '%');
				
				// Store new average percentage
				$container.data('avg-percentage', data.rating_percentage);

				if ($text.length) {
					$text.css('opacity', '0');
					setTimeout(function () {
						if (data.rating_count > 0) {
							$text.html(
								'<span class="rating-avg">' + data.rating_avg + '</span> ' +
								'(<span class="rating-count">' + data.rating_count + '</span> ' +
								(data.rating_count == 1 ? ratingLang.vote : ratingLang.votes) + ')'
							);
						} else {
							var entityType = $container.data('entity-type');
							var placeholder = entityType === 'profile' ? ratingLang.notRatedYet : ratingLang.ratingTopic;
							$text.html('<span class="rating-bold">' + placeholder + '</span>');
						}
						$text.css('opacity', '1');
					}, 300);
				}

				// Update user rating checkmark
				$stars.find('.user-rating-indicator').remove();
				if (data.user_rating >= 1 && data.user_rating <= 5) {
					$stars.append('<i class="icon fa fa-check-circle user-rating-indicator" data-star="' + data.user_rating + '" aria-hidden="true"></i>');
				}

				$container.data('user-rating', data.user_rating);
			}

			if (ratingMode == 2 || ratingMode == 3) {
				var $up = $container.find('.vote-up');
				var $down = $container.find('.vote-down');

				$up.find('.vote-count').text(data.upvotes);
				if (ratingMode == 2) {
					$down.find('.vote-count').text(data.downvotes);
				}

				$container.find('.user-voted').remove();

				if (!$container.data('allow-revote')) {
					if (data.user_rating === 0) {
						// No vote - enable both buttons
						$up.add($down).removeClass('vote-disabled');
					} else {
						// Has voted - disable the opposite button
						$up.add($down).addClass('vote-disabled');
						if (data.user_rating == 10) $up.removeClass('vote-disabled');
						if (ratingMode == 2 && data.user_rating == -10) $down.removeClass('vote-disabled');
					}
				}

				if (data.user_rating == 10) {
					$up.append('<i class="icon fa fa-check-circle user-voted"></i>');
				} else if (ratingMode == 2 && data.user_rating == -10) {
					$down.append('<i class="icon fa fa-check-circle user-voted"></i>');
				}

				$container.data('user-rating', data.user_rating);
			}
			
			// Update remove link visibility
			var allowRemove = $container.data('allow-remove');
			var allowRevote = $container.data('allow-revote');

			// Disable interaction if already voted and revote not allowed
			if (!allowRevote && data.user_rating && data.user_rating !== 0) {
				$container.addClass('rating-already-voted');
			} else if (data.user_rating === 0) {
				$container.removeClass('rating-already-voted');
			}
			
			if (allowRemove) {
				// Find the remove link holder in the heading
				var $holder = $container.closest('.inner').find('.rating-remove-holder');
				var $removeLink = $holder.find('.rating-remove-link');
				
				if (data.user_rating && data.user_rating !== 0) {
					// User has voted - show remove link with fresh hash
					var removeHash = data.remove_hash || $container.data('remove-hash');
					
					if ($removeLink.length === 0) {
						// Create remove link in the heading
						$holder.html('<a href="#" class="rating-remove-link link-danger" data-remove-hash="' + removeHash + '">' + ratingLang.removeVote + '</a>');
					} else {
						// Update existing link with new hash
						$removeLink.attr('data-remove-hash', removeHash);
						$removeLink.show();
					}
					
					// Store new hash for next time
					if (data.remove_hash) {
						$container.data('remove-hash', data.remove_hash);
					}
				} else {
					// User removed vote - hide remove link
					$removeLink.hide();
				}
			}
			
			// Show/hide trashcan based on whether ratings exist
			var canModDelete = $container.data('can-mod-delete');
			if (canModDelete) {
				var $trash = $container.closest('.inner').find('.rating-mod-delete-link');
				var hasRatings = false;
				if (ratingMode == 1) {
					hasRatings = data.rating_count > 0;
				} else {
					hasRatings = data.upvotes > 0 || data.downvotes > 0;
				}
				if (hasRatings) {
					$trash.show();
				} else {
					$trash.hide();
				}
			}
		},

	};

	$(function () {
		if ($('.topic-rating-container').length) {
			// Store initial average percentage for each container
			$('.topic-rating-container').each(function() {
				var $container = $(this);
				var $stars = $container.find('.rating-stars');
				if ($stars.length) {
					var $filled = $stars.find('.stars-filled');
					var currentWidth = parseFloat($filled.css('width')) || 0;
					var totalWidth = parseFloat($stars.css('width')) || 1;
					var percentage = (currentWidth / totalWidth) * 100;
					$container.data('avg-percentage', percentage);
				}
			});
			
			// Check localStorage for guest ratings on page load
			if (ratingIsGuest && typeof(Storage) !== 'undefined') {
				$('.topic-rating-container').each(function() {
					var $container = $(this);
					var entityType = $container.data('entity-type');
					var storedRating, storageKey;
					
					if (entityType === 'profile') {
						var userId = $container.data('user-id');
						storageKey = 'profile_rating_' + userId;
					} else {
						var topicId = $container.data('topic-id');
						storageKey = 'topic_rating_' + topicId;
					}
					
					storedRating = localStorage.getItem(storageKey);
					
					if (storedRating) {
						var storedRatingInt = parseInt(storedRating, 10);
						var ratingMode = $container.data('rating-mode');
						var isStarRating = storedRatingInt >= 1 && storedRatingInt <= 5;
						var isVoteRating = storedRatingInt == 10 || storedRatingInt == -10;
						
						// Only apply stored rating if it matches current mode
						var matchesCurrentMode = (ratingMode == 1 && isStarRating) || (ratingMode != 1 && isVoteRating);
						
						if (matchesCurrentMode && parseInt($container.data('user-rating'), 10) === 0) {
							$container.data('user-rating', storedRatingInt);
							// Disable interaction if revote not allowed
							if (!$container.data('allow-revote')) {
								$container.addClass('rating-already-voted');
							}
						}
						
						// Update star display if applicable
						var $stars = $container.find('.rating-stars');
						if ($stars.length && isStarRating && ratingMode == 1) {
							// Add checkmark
							$stars.find('.user-rating-indicator').remove();
							$stars.append('<i class="icon fa fa-check-circle user-rating-indicator" data-star="' + storedRatingInt + '" aria-hidden="true"></i>');
						}
						
						// Update vote button display if applicable
						if ((ratingMode == 2 || ratingMode == 3) && isVoteRating) {
							var allowRevote = $container.data('allow-revote');
							var $up = $container.find('.vote-up');
							var $down = $container.find('.vote-down');
							
							if (!allowRevote) {
								$up.add($down).addClass('vote-disabled');
								if (storedRatingInt == 10) $up.removeClass('vote-disabled');
								if (ratingMode == 2 && storedRatingInt == -10) $down.removeClass('vote-disabled');
							}
							
							if (storedRatingInt == 10) {
								$up.append('<i class="icon fa-check-circle user-voted"></i>');
							} else if (ratingMode == 2 && storedRatingInt == -10) {
								$down.append('<i class="icon fa fa-check-circle user-voted"></i>');
							}
						}
					}
				});
			}
			
			// Show remove link on page load for users who have already voted
			$('.topic-rating-container').each(function() {
				var $container = $(this);
				var allowRemove = $container.data('allow-remove');
				var userRating = parseInt($container.data('user-rating'), 10);
				
				if (allowRemove && userRating && userRating !== 0 && $container.data('can-rate')) {
					var removeHash = $container.data('remove-hash');
					var $holder = $container.closest('.inner').find('.rating-remove-holder');
					
					if ($holder.length && removeHash) {
						$holder.html('<a href="#" class="rating-remove-link link-danger" data-remove-hash="' + removeHash + '">' + ratingLang.removeVote + '</a>');
					}
				}
			});
			
			topicRating.init();
		}
	});

})(jQuery);
