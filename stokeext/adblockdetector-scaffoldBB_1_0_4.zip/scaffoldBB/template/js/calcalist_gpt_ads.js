
'use strict';

function createHiddenDiv(id) {
  const div = document.createElement('div');
  div.id = id;
  div.style.display = 'none';
  document.body.appendChild(div);
}

createHiddenDiv('medister');
createHiddenDiv('frikadelle');