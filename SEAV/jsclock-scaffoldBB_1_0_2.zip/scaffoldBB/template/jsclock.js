setInterval(showTime, 1000);
function showTime()
{
	let time = new Date();
	let hour = time.getHours();
	let ampm = time.getHours();
	let min = time.getMinutes();
	let sec = time.getSeconds();
	let sep = '<span>:</span>';

	hour = ('0' + hour).slice(-2);
	min = ('0' + min).slice(-2);
	sec = ('0' + sec).slice(-2);

	if (jsclockformatswitch == true)
	{
		if (hour > 12) {
			hour -= 12;
		}
		if (hour == 0) {
			hour = 12;
		}
		if (ampm >= 0 && ampm <= 11)
		{
			time_for_clock	= hour + sep + min + sep + sec + ' ' + clock_format_am;
		}
		else
		{
			if (ampm >= 13 && ampm <= 21)
			{
				time_for_clock	= '0' + hour + sep + min + sep + sec + ' ' +  clock_format_pm;
			}
			else
			{
				time_for_clock	= hour + sep + min + sep + sec + ' ' + clock_format_pm;
			}
		}
	}
	else
	{
		time_for_clock	= hour + sep + min + sep + sec ;
	}

	let currentTime = time_for_clock ;

	document.getElementById("jsclock").innerHTML = currentTime;
}

showTime();
